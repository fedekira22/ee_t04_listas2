/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author FEDE
 */
public class Nodo {
    int dato;
    Nodo siguiente ;//puntero enlace
    
    public Nodo(int d)
    {
        this.dato=d;
    }
    
    public Nodo(int d,Nodo n )
    {
        dato=d;
                siguiente=n;
    }
    
    public int getNodo()
    {
        return dato;
    }
    public Nodo getSiguiente(){
            return siguiente;
    
    }
    
    public void setNodo(int x)
    {
        x=dato;
        
    }
    
    public void setSiguiente(Nodo f)
    {
        f=siguiente;
        
        
    }
    
    
}
