

/**
 *
 * @author FEDE
 */
public class Lista {
    
    protected  Nodo inicio,fin;// punteros para saber donde esta el inicio y el final 
    
    public Lista()
    {
        inicio=null;
        fin=null;
        
    }
    //metodo de saber si la lista esta vacia 
    public void estavacia(int elemento)
    {
        inicio=new Nodo(elemento,inicio);
        if(inicio==fin)
        {fin=inicio;
        
        }
        
    }
    public void agregarAlfinal(int elemento)
    {
        if(!estavacia())  {
            fin.siguiente=new Nodo(elemento);
            fin=fin.siguiente;
        }else 
        {
            inicio=fin=new Nodo(elemento);
            
        }
        
    }
    
    //método para agregar al inicio de la lista
    public void agregarAlInicio(int elemento)
    {
        // creando al nodo
        inicio=new Nodo(elemento, inicio);
        if(fin==null)
        {
            fin=inicio;
            
        }
         
    }
     public void agregarAlFinal(int elemento )
        {
            fin=new Nodo(elemento,fin);
            if(inicio==null)
            {
                inicio=fin;
            }
            
        }
   
    //metodo para mostrar los datos
    public void mostrarLita()
    {
        Nodo recorrer=inicio;
        while(recorrer!=null)
        {
            
            System.out.print("["+recorrer.dato+"]--->"+recorrer.getSiguiente());
            recorrer=recorrer.siguiente;   
        }
        
    }
   
    
    public Nodo getInicio()
    {
        return inicio;
    }
    public Nodo getFinal()
    {
        return fin;
    }
  
    
    public void setInicio(Nodo x)
    {
        x=inicio;
    }
    
    public void setFinal(Nodo c)
    {
        c=fin;
    }
            
    @Override
    public String toString()
    {
        String s="";
        s+=inicio+"--->"+fin+"]";
        return s;
        
    }

    private boolean estavacia() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
    
    public boolean detectarciclo(Lista m )
    {
        
       
    boolean flag=false;
    if(estavacia())
    {
        flag=true;
        m.mostrarLita();
    }
    else{
        System.out.println("no se cicla ");
    }
    
       
        
        
        
          
        return flag ;
    }
    
    
    
    
}
