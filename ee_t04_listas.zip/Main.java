
import javax.swing.JOptionPane;


/**
 *
 * @author FEDE
 */
public class Main {
      public static void main(String [] args)
    {
        int opcion=0,el=0;
        Lista l=new Lista();
        do{
            try{
                opcion=Integer.parseInt(JOptionPane.showInputDialog(null,"1agregar\n 2 mostrar datos\n "+" 3 salir"));
               switch(opcion)
               {
                   case 1:
                       try{
                          el=Integer.parseInt(JOptionPane.showInputDialog(null,"ingresa el elemento al inicio de la lista \n  2 mostrar " +3));
                         //agregando al nodo
                          l.agregarAlInicio(el);
                          
                       }catch(NumberFormatException n){
                           JOptionPane.showInputDialog(null,"error"+n.getMessage());
                           
                       }
                       break;
                   case 2:
                      
                       l.mostrarLita();
                        System.out.println( );
                       
                       break;
                   case 3:
                       break;
                   default:
                       
               }
                
                
                
            }catch(Exception e){
                JOptionPane.showInputDialog("no se puede insertar "+
        e.getMessage());
                
            }
        }while(opcion!=3);
    }
}
